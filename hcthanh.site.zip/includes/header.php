<header class="header-area header-sticky">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <nav class="main-nav">
                    <!-- ***** Logo Start ***** -->
                    <a href="./index.php" class="logo">
                        <img src="./assets/images/logo.png" alt="">
                         <!-- <h1 style="color: #ec6090;">HcThanh</h1> -->
                    </a>
                    <!-- ***** Logo End ***** -->
                    <!-- ***** Search End ***** -->
                    <div class="search-input">
                      <form id="search" action="#">
                        <input type="text" placeholder="Type Something" id='searchText' name="searchKeyword" onkeypress="handle" />
                        <i class="fa fa-search"></i>
                      </form>
                    </div>
                    <!-- ***** Search End ***** -->
                    <!-- ***** Menu Start ***** -->
                    <ul class="nav">
                        <li><a href="./index.php" class="active">Trang chủ</a></li>
                        <li><a href="./browse.html">Browse</a></li>
                        <li><a href="./details.php">Nạp tiền</a></li>
                        <li><a href="./streams.html">Streams</a></li>
                        <li><a href="./login.php">Đăng nhập</a></li>
                        <li><a href="./profile.html">Profile <img src="./assets/images/profile-header.jpg" alt=""></a></li>
                        
                    </ul>   
                    <a class='menu-trigger'>
                        <span>Menu</span>
                    </a>
                    <!-- ***** Menu End ***** -->
                </nav>
            </div>
        </div>
    </div>
  </header>