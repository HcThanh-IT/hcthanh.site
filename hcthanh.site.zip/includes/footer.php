<footer>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <p>Created and developed by <a href="https://www.hcthanh.site/" target="_blank" >HcThanh</a> 2024.</p>
        </div>
      </div>
    </div>
  </footer>